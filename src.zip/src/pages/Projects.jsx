export default function Projects() {
  return (
    <div className="container text-light py-5">

      <h2 className="text-center text-warning mb-4">Projects</h2>

      <div className="row">

        <div className="col-md-4">
          <div className="card project-card p-3">

            <h5>Travel To Egypt</h5>

            <p>Frontend website built using HTML, CSS and JavaScript.</p>

            <a
              href="https://samarabdu.github.io/travel_to_egypt/"
              className="btn btn-warning"
            >
              View Project
            </a>

          </div>
        </div>

      </div>

    </div>
  );
}
