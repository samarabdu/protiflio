import { useState } from "react";
import hero1 from "../assets/hero1.jpg";
import hero2 from "../assets/hero2.jpg";

export default function Home() {
  const [section, setSection] = useState(1);

  return (
    <div className="home-wrapper d-flex">

      {/* Sidebar */}
      <div className="sidebar d-flex flex-column justify-content-center align-items-center text-center">

        <img
          src="/profile.jpg"
          alt="profile"
          className="sidebar-img mb-3"
        />

        <h4 className="fw-bold">Samar Khaled</h4>
        <p className="text-muted small">Frontend Developer</p>

        <nav className="nav flex-column mt-4">
          <a className="nav-link sidebar-link" onClick={() => setSection(1)}>Home</a>
          <a className="nav-link sidebar-link" onClick={() => setSection(2)}>About</a>
          <a className="nav-link sidebar-link">Skills</a>
          <a className="nav-link sidebar-link">Projects</a>
          <a className="nav-link sidebar-link">Contact</a>
        </nav>

      </div>

      {/* Content */}
      <div className="content flex-grow-1">

        {/* Section 1 */}
        {section === 1 && (
          <section
            className="hero-section d-flex align-items-center"
            style={{ backgroundImage: `url(${hero1})` }}
          >
            <div className="container text-white">
              <h1 className="display-4 fw-bold">I am a Developer</h1>

              <p className="mt-3">
                100% HTML5 Bootstrap Templates Made <br />
                By Colorlib.com
              </p>

              <button className="btn btn-outline-dark mt-3 px-4 py-2">
                VIEW PORTFOLIO
              </button>
            </div>
          </section>
        )}

        {/* Section 2 */}
        {section === 2 && (
          <section
            className="hero-section d-flex align-items-center"
            style={{ backgroundImage: `url(${hero2})` }}
          >
            <div className="container text-white">
              <h1 className="display-4 fw-bold">
                I'm Samar Khaled
              </h1>

              <p className="mt-3">
                Frontend Developer passionate about building beautiful
                and user-friendly websites.
              </p>

              <a
                href="/cv.pdf"
                className="btn btn-light mt-3 px-4 py-2"
                download
              >
                DOWNLOAD CV
              </a>
            </div>
          </section>
        )}

      </div>
    </div>
  );
}