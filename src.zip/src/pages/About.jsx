export default function About() {
  return (
    <div className="page">
      <h2>About Me</h2>

      <p>
        I am Samar Khaled Abdu, a Frontend Developer passionate about building
        modern, responsive web applications with clean UI and great user
        experience.
      </p>
    </div>
  );
}