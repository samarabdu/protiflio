export default function Contact() {
  return (
    <div className="container text-light py-5">

      <h2 className="text-center text-warning mb-4">Contact Me</h2>

      <form className="col-md-6 mx-auto">

        <input
          type="text"
          className="form-control mb-3"
          placeholder="Your Name"
        />

        <input
          type="email"
          className="form-control mb-3"
          placeholder="Email"
        />

        <textarea
          className="form-control mb-3"
          rows="4"
          placeholder="Message"
        ></textarea>

        <button className="btn btn-warning w-100">
          Send Message
        </button>

      </form>

    </div>
  );
}