export default function Skills() {
  return (
    <div className="page">
      <h2>My Skills</h2>

      <ul>
        <li>HTML / CSS / Bootstrap</li>
        <li>JavaScript / React</li>
        <li>UI / UX Design</li>
        <li>Testing & Automation</li>
      </ul>
    </div>
  );
}
