import { NavLink } from "react-router-dom";
import profile from "../assets/profile.jpg";

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="text-center">
        <img src={profile} alt="profile" className="profile-img" />

        <h3 className="name">Samar Khaled Abdu</h3>

        <p className="role">Frontend Developer</p>
      </div>

      <nav className="menu">
        <NavLink to="/">HOME</NavLink>
        <NavLink to="/about">ABOUT</NavLink>
        <NavLink to="/skills">SKILLS</NavLink>
        <NavLink to="/projects">PROJECTS</NavLink>
        <NavLink to="/contact">CONTACT</NavLink>
      </nav>
    </aside>
  );
}